import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-monster-card',
  standalone: true,
  templateUrl: './monster-card.html',
  styleUrl: './monster-card.css'
})
export class MonsterCard {

  @Input() titulo: string = '';
  @Input() subtitulo: string = '';
  @Input() descripcion: string = '';
  @Input() imagen: string = '';
  @Input() pie: string = '';

}